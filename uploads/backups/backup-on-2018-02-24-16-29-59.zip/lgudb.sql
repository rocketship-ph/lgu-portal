#
# TABLE STRUCTURE FOR: tblaudittrail
#

DROP TABLE IF EXISTS `tblaudittrail`;

CREATE TABLE `tblaudittrail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(100) NOT NULL,
  `action` varchar(300) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user` varchar(100) NOT NULL,
  `ipaddress` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=372 DEFAULT CHARSET=latin1;

INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('166', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 21:31:34', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('167', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 21:43:25', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('168', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 21:43:29', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('169', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 21:59:11', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('170', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 21:59:14', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('171', 'Account Module', 'Create User Account [HRD1234567890]', '2018-01-21 22:00:47', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('172', 'Account Module', 'Assign Roles [HRD1234567890]', '2018-01-21 22:01:44', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('173', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:01:50', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('174', 'Session Module', 'User Log In [HRD1234567890]', '2018-01-21 22:02:01', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('175', 'RSP Module', 'Create New Competency Title', '2018-01-21 22:02:59', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('176', 'RSP Module', 'Create New Position [INFODESKSTAF1]', '2018-01-21 22:03:46', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('177', 'Session Module', 'User Log Out [HRD1234567890]', '2018-01-21 22:06:33', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('178', 'Session Module', 'User Log In [HRD1234567890]', '2018-01-21 22:06:37', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('179', 'Session Module', 'User Log Out [HRD1234567890]', '2018-01-21 22:11:14', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('180', 'Session Module', 'User Log In [HRD1234567890]', '2018-01-21 22:12:45', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('181', 'Session Module', 'User Log Out [HRD1234567890]', '2018-01-21 22:12:50', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('182', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:12:56', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('183', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:16:31', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('184', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:16:35', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('185', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:18:31', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('186', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:22:00', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('187', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:22:03', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('188', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:23:15', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('189', 'Utilities Module', 'Create Database Backup', '2018-01-21 22:23:33', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('190', 'Utilities Module', 'Download Database Backup', '2018-01-21 22:23:36', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('191', 'Account Module', 'Change User Password [ADMIN]', '2018-01-21 22:24:05', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('192', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:24:07', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('193', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:24:13', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('194', 'Account Module', 'Change User Password [ADMIN]', '2018-01-21 22:24:24', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('195', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:24:25', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('196', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:24:31', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('197', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:24:38', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('198', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:30:32', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('199', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:31:33', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('200', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 22:39:45', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('201', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 22:54:05', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('202', 'Session Module', 'User Log In [HRD1234567890]', '2018-01-21 22:54:36', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('203', 'Session Module', 'User Log Out [HRD1234567890]', '2018-01-21 22:55:18', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('204', 'Session Module', 'User Log In [ADMIN]', '2018-01-22 01:27:57', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('205', 'Session Module', 'User Log In [ADMIN]', '2018-01-22 08:15:08', 'ADMIN', '121.58.199.8');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('206', 'Session Module', 'User Log In [ADMIN]', '2018-01-22 09:03:23', 'ADMIN', '121.58.199.8');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('207', 'Session Module', 'User Log Out [ADMIN]', '2018-01-22 09:11:48', 'ADMIN', '121.58.199.8');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('208', 'Session Module', 'User Log In [ADMIN]', '2018-01-22 09:22:54', 'ADMIN', '121.58.199.8');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('209', 'Session Module', 'User Log Out [ADMIN]', '2018-01-22 09:28:34', 'ADMIN', '121.58.199.8');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('210', 'Session Module', 'User Log In [ADMIN]', '2018-01-22 15:13:47', 'ADMIN', '121.58.199.8');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('211', 'Session Module', 'User Log Out [ADMIN]', '2018-01-22 15:16:08', 'ADMIN', '121.58.199.8');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('212', 'Session Module', 'User Log In [ADMIN]', '2018-01-23 21:41:07', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('213', 'Session Module', 'User Log In [ADMIN]', '2018-01-23 21:51:59', 'ADMIN', '223.25.26.32');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('214', 'Session Module', 'User Log Out [ADMIN]', '2018-01-23 21:52:26', 'ADMIN', '223.25.26.32');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('215', 'Session Module', 'User Log In [ADMIN]', '2018-01-25 17:33:32', 'ADMIN', '110.54.226.217');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('216', 'Session Module', 'User Log In [ADMIN]', '2018-01-26 11:49:51', 'ADMIN', '122.54.120.196');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('217', 'Session Module', 'User Log Out [ADMIN]', '2018-01-26 11:53:47', 'ADMIN', '122.54.120.196');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('218', 'Session Module', 'User Log In [ADMIN]', '2018-01-26 11:54:54', 'ADMIN', '122.54.120.196');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('219', 'Session Module', 'User Log In [ADMIN]', '2018-01-26 11:56:02', 'ADMIN', '49.151.250.49');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('220', 'RSP Module', 'Create New Position [ADMIAIDEIII]', '2018-01-26 11:56:51', 'ADMIN', '122.54.120.196');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('221', 'Session Module', 'User Log In [ADMIN]', '2018-01-26 22:02:54', 'ADMIN', '223.25.26.22');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('222', 'Session Module', 'User Log Out [ADMIN]', '2018-01-26 22:03:55', 'ADMIN', '223.25.26.22');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('223', 'Session Module', 'User Log In [ADMIN]', '2018-01-27 22:12:01', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('224', 'Session Module', 'User Log In [ADMIN]', '2018-01-29 20:12:14', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('225', 'Session Module', 'User Log In [ADMIN]', '2018-01-30 11:35:04', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('226', 'Session Module', 'User Log In [ADMIN]', '2018-01-30 22:17:41', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('227', 'Utilities Module', 'Download Database Backup', '2018-01-30 22:18:24', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('228', 'Session Module', 'User Log In [ADMIN]', '2018-02-01 23:47:41', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('229', 'Session Module', 'User Log In [ADMIN]', '2018-02-04 19:54:34', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('230', 'Session Module', 'User Log In [ADMIN]', '2018-02-04 23:14:17', 'ADMIN', '103.196.137.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('231', 'Session Module', 'User Log In [ADMIN]', '2018-02-07 10:19:02', 'ADMIN', '175.158.218.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('232', 'Account Module', 'Assign Roles [HRD1234567890]', '2018-02-07 10:21:55', 'ADMIN', '175.158.218.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('233', 'Session Module', 'User Log Out [ADMIN]', '2018-02-07 10:38:34', 'ADMIN', '175.158.218.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('234', 'Session Module', 'User Log In [ADMIN]', '2018-02-07 10:46:36', 'ADMIN', '175.158.218.203');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('235', 'Session Module', 'User Log In [ADMIN]', '2018-02-07 11:42:01', 'ADMIN', '124.6.142.194');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('236', 'Session Module', 'User Log In [ADMIN]', '2018-02-07 13:41:12', 'ADMIN', '223.25.26.74');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('237', 'Session Module', 'User Log In [ADMIN]', '2018-02-10 10:31:46', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('238', 'Session Module', 'User Log In [ADMIN]', '2018-02-11 17:46:58', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('239', 'RSP Module', 'Create New Competency Index', '2018-02-11 21:33:28', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('240', 'RSP Module', 'Create New Competency Index', '2018-02-11 21:44:37', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('241', 'RSP Module', 'Create New Competency Index', '2018-02-11 21:47:39', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('242', 'RSP Module', 'Create New Competency Index', '2018-02-11 21:55:42', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('243', 'RSP Module', 'Create New Competency Index', '2018-02-11 22:00:06', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('244', 'RSP Module', 'Edit Competency Index', '2018-02-11 23:08:15', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('245', 'RSP Module', 'Delete Competency Index', '2018-02-11 23:08:40', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('246', 'RSP Module', 'Delete Competency Index', '2018-02-11 23:08:45', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('247', 'RSP Module', 'Delete Competency Index', '2018-02-11 23:08:52', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('248', 'RSP Module', 'Delete Competency Index', '2018-02-11 23:09:04', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('249', 'Account Module', 'Create User Account [ID234567]', '2018-02-11 23:16:21', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('250', 'Account Module', 'Assign Roles [ID234567]', '2018-02-11 23:17:06', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('251', 'Session Module', 'User Log Out [ADMIN]', '2018-02-11 23:17:10', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('252', 'Session Module', 'User Log In [ID234567]', '2018-02-11 23:17:17', 'ID234567', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('253', 'RSP Module', 'Delete Competency Index', '2018-02-11 23:46:25', 'ID234567', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('254', 'Session Module', 'User Log Out [ID234567]', '2018-02-11 23:49:21', 'ID234567', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('255', 'Session Module', 'User Log In [ID234567]', '2018-02-11 23:49:26', 'ID234567', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('256', 'Session Module', 'User Log In [ADMIN]', '2018-02-12 22:33:48', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('257', 'RSP Module', 'Edit Competency Index', '2018-02-12 22:39:30', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('258', 'RSP Module', 'Edit Competency Index', '2018-02-12 22:39:46', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('259', 'RSP Module', 'Edit Competency Index', '2018-02-12 23:18:25', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('260', 'Session Module', 'User Log Out [ADMIN]', '2018-02-12 23:20:26', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('261', 'Session Module', 'User Log In [ID234567]', '2018-02-12 23:20:32', 'ID234567', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('262', 'Session Module', 'User Log Out [ID234567]', '2018-02-12 23:58:49', 'ID234567', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('263', 'Session Module', 'User Log In [ADMIN]', '2018-02-12 23:58:56', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('264', 'Session Module', 'User Log Out [ADMIN]', '2018-02-13 00:03:33', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('265', 'Session Module', 'User Log In [ADMIN]', '2018-02-13 00:08:18', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('266', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 13:19:57', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('267', 'Session Module', 'User Log Out [ADMIN]', '2018-02-18 13:28:42', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('268', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 15:51:31', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('269', 'Session Module', 'User Log Out [ADMIN]', '2018-02-18 16:03:00', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('270', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 18:55:39', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('271', 'Session Module', 'User Log Out [ADMIN]', '2018-02-18 19:05:49', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('272', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 19:05:58', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('273', 'Session Module', 'User Log Out [ADMIN]', '2018-02-18 19:06:03', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('274', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 19:49:40', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('275', 'Session Module', 'User Log Out [ADMIN]', '2018-02-18 20:22:18', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('276', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 20:42:20', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('277', 'Session Module', 'User Log Out [ADMIN]', '2018-02-18 21:41:51', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('278', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 21:41:58', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('279', 'Session Module', 'User Log Out [ADMIN]', '2018-02-18 23:02:26', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('280', 'Session Module', 'User Log In [ADMIN]', '2018-02-18 23:37:23', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('281', 'Session Module', 'User Log Out [ADMIN]', '2018-02-19 00:48:15', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('282', 'Session Module', 'User Log In [ADMIN]', '2018-02-20 18:14:59', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('283', 'Session Module', 'User Log Out [ADMIN]', '2018-02-20 18:15:25', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('284', 'Session Module', 'User Log In [ADMIN]', '2018-02-20 20:57:50', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('285', 'RSP Module', 'Create New Competency Title', '2018-02-20 20:58:09', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('286', 'Session Module', 'User Log In [ADMIN]', '2018-02-20 21:01:43', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('287', 'Session Module', 'User Log Out [ADMIN]', '2018-02-20 21:36:57', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('288', 'Session Module', 'User Log In [ADMIN]', '2018-02-20 23:21:43', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('289', 'Session Module', 'User Log In [ADMIN]', '2018-02-22 01:34:44', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('290', 'Session Module', 'User Log In [ADMIN]', '2018-02-22 01:36:05', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('291', 'Session Module', 'User Log In [ADMIN]', '2018-02-22 19:41:17', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('292', 'Session Module', 'User Log Out [ADMIN]', '2018-02-22 22:01:27', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('293', 'Session Module', 'User Log In [ADMIN]', '2018-02-22 22:01:57', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('294', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 01:44:54', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('295', 'Session Module', 'User Log In [HRD1234567890]', '2018-02-23 01:45:04', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('296', 'Session Module', 'User Log Out [HRD1234567890]', '2018-02-23 01:45:16', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('297', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 01:46:17', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('298', 'Account Module', 'Create User Account [MAYOR001]', '2018-02-23 01:47:47', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('299', 'Account Module', 'Create User Account [ITMGR001]', '2018-02-23 01:49:12', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('300', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 01:51:53', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('301', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 01:52:04', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('302', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 01:52:49', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('303', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 01:52:59', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('304', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 01:55:13', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('305', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 02:00:45', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('306', 'Session Module', 'User Log In [HRD1234567890]', '2018-02-23 02:00:52', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('307', 'Session Module', 'User Log Out [HRD1234567890]', '2018-02-23 02:04:29', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('308', 'Session Module', 'User Log In [HRD1234567890]', '2018-02-23 02:04:39', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('309', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 02:12:44', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('310', 'Session Module', 'User Log In [HRD1234567890]', '2018-02-23 02:12:53', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('311', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 02:21:30', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('312', 'Account Module', 'Create User Account [DEPTHEAD001]', '2018-02-23 02:22:15', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('313', 'Session Module', 'User Log Out [HRD1234567890]', '2018-02-23 02:41:44', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('314', 'Session Module', 'User Log In [MAYOR001]', '2018-02-23 02:41:51', 'MAYOR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('315', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 02:42:49', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('316', 'Account Module', 'Update User Account [MAYOR001]', '2018-02-23 02:43:06', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('317', 'Session Module', 'User Log Out [MAYOR001]', '2018-02-23 02:43:12', 'MAYOR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('318', 'Session Module', 'User Log In [MAYOR001]', '2018-02-23 02:43:22', 'MAYOR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('319', 'Account Module', 'Delete User Account [MAYOR001]', '2018-02-23 02:44:55', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('320', 'Account Module', 'Create User Account [MAYOR01]', '2018-02-23 02:45:25', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('321', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 02:45:30', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('322', 'Session Module', 'User Log Out [MAYOR001]', '2018-02-23 02:45:33', 'MAYOR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('323', 'Session Module', 'User Log In [MAYOR01]', '2018-02-23 02:45:46', 'MAYOR01', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('324', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 02:47:58', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('325', 'Session Module', 'User Log Out [MAYOR01]', '2018-02-23 02:58:54', 'MAYOR01', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('326', 'Session Module', 'User Log In [HRD1234567890]', '2018-02-23 02:59:12', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('327', 'Session Module', 'User Log Out [HRD1234567890]', '2018-02-23 03:16:21', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('328', 'Session Module', 'User Log In [ITMGR001]', '2018-02-23 03:16:32', 'ITMGR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('329', 'Account Module', 'Update User Account [ITMGR001]', '2018-02-23 03:17:12', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('330', 'Session Module', 'User Log Out [ITMGR001]', '2018-02-23 03:17:15', 'ITMGR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('331', 'Account Module', 'Reset User Password [ITMGR001]', '2018-02-23 03:17:48', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('332', 'Session Module', 'User Log In [ITMGR001]', '2018-02-23 03:17:52', 'ITMGR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('333', 'Session Module', 'User Log Out [ITMGR001]', '2018-02-23 03:26:23', 'ITMGR001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('334', 'Session Module', 'User Log In [DEPTHEAD001]', '2018-02-23 03:26:35', 'DEPTHEAD001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('335', 'Session Module', 'User Log Out [DEPTHEAD001]', '2018-02-23 03:40:55', 'DEPTHEAD001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('336', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 03:41:03', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('337', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 03:41:48', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('338', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 04:26:07', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('339', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 04:28:28', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('340', 'Account Module', 'Create User Account [EliMap2018-001]', '2018-02-23 04:36:20', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('341', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 04:36:24', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('342', 'Session Module', 'User Log In [EliMap2018-001]', '2018-02-23 04:36:35', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('343', 'Account Module', 'Change User Password [EliMap2018-001]', '2018-02-23 04:36:50', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('344', 'Session Module', 'User Log Out [EliMap2018-001]', '2018-02-23 04:36:52', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('345', 'Session Module', 'User Log In [EliMap2018-001]', '2018-02-23 04:36:57', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('346', 'Session Module', 'User Log Out [EliMap2018-001]', '2018-02-23 04:37:02', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('347', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 04:37:45', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('348', 'Account Module', 'Create User Account [SERVANT001]', '2018-02-23 04:38:36', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('349', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 04:38:39', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('350', 'Session Module', 'User Log In [SERVANT001]', '2018-02-23 04:38:52', 'SERVANT001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('351', 'Session Module', 'User Log In [SERVANT001]', '2018-02-23 04:39:16', 'SERVANT001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('352', 'Session Module', 'User Log Out [SERVANT001]', '2018-02-23 04:45:26', 'SERVANT001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('353', 'Session Module', 'User Log In [EliMap2018-001]', '2018-02-23 04:45:51', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('354', 'Session Module', 'User Log Out [EliMap2018-001]', '2018-02-23 04:49:32', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('355', 'Session Module', 'User Log In [EliMap2018-001]', '2018-02-23 04:49:39', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('356', 'Session Module', 'User Log Out [EliMap2018-001]', '2018-02-23 04:50:16', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('357', 'Session Module', 'User Log In [EliMap2018-001]', '2018-02-23 04:50:37', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('358', 'Session Module', 'User Log Out [EliMap2018-001]', '2018-02-23 04:51:32', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('359', 'Session Module', 'User Log In [EliMap2018-001]', '2018-02-23 04:51:38', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('360', 'Session Module', 'User Log Out [EliMap2018-001]', '2018-02-23 05:13:23', 'EliMap2018-001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('361', 'Session Module', 'User Log In [DEPTHEAD001]', '2018-02-23 05:13:33', 'DEPTHEAD001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('362', 'Session Module', 'User Log Out [DEPTHEAD001]', '2018-02-23 05:13:39', 'DEPTHEAD001', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('363', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 05:15:38', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('364', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 05:46:05', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('365', 'Session Module', 'User Log In [ADMIN]', '2018-02-23 05:47:13', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('366', 'Session Module', 'User Log Out [ADMIN]', '2018-02-23 05:47:16', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('367', 'Session Module', 'User Log In [HRD1234567890]', '2018-02-23 05:47:41', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('368', 'Session Module', 'User Log In [ADMIN]', '2018-02-24 22:26:22', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('369', 'Account Module', 'Assign Roles [MAYOR01]', '2018-02-25 00:21:56', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('370', 'Account Module', 'Assign Roles [MAYOR01]', '2018-02-25 00:22:06', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('371', 'Account Module', 'Assign Roles [MAYOR01]', '2018-02-25 00:25:58', 'ADMIN', '127.0.0.1');


#
# TABLE STRUCTURE FOR: tblbackups
#

DROP TABLE IF EXISTS `tblbackups`;

CREATE TABLE `tblbackups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdby` varchar(100) NOT NULL,
  `backupname` varchar(100) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `path` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tblbackups` (`id`, `datecreated`, `createdby`, `backupname`, `filename`, `path`, `status`) VALUES ('12', '2018-01-21 22:23:33', 'ADMIN', 'db-backup2018-01-21-14-23-33', 'backup-on-2018-01-21-14-23-33.zip', 'uploads/backups/backup-on-2018-01-21-14-23-33.zip', '0');


#
# TABLE STRUCTURE FOR: tblcompetency
#

DROP TABLE IF EXISTS `tblcompetency`;

CREATE TABLE `tblcompetency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `title` varchar(100) NOT NULL,
  `description` varchar(3000) NOT NULL,
  `createdby` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `tblcompetency` (`id`, `datecreated`, `title`, `description`, `createdby`) VALUES ('13', '2018-01-21 22:02:59', 'Organizational Competency', 'VGhpcyBpcyBhIGRlc2NyaXB0aW9uIHRlc3Q=', 'HRD1234567890');
INSERT INTO `tblcompetency` (`id`, `datecreated`, `title`, `description`, `createdby`) VALUES ('14', '2018-02-20 20:58:09', 'ytreryuyt', 'ZXJ0eXRyZXJ0eQ==', 'ADMIN');


#
# TABLE STRUCTURE FOR: tblcompetencyindex
#

DROP TABLE IF EXISTS `tblcompetencyindex`;

CREATE TABLE `tblcompetencyindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdby` varchar(50) NOT NULL,
  `competencytitle` varchar(100) NOT NULL,
  `competencyarea` varchar(100) NOT NULL,
  `competencydescription` varchar(1000) NOT NULL,
  `levels` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `tblcompetencyindex` (`id`, `datecreated`, `datemodified`, `createdby`, `competencytitle`, `competencyarea`, `competencydescription`, `levels`) VALUES ('9', '2018-02-11 22:00:06', '2018-02-12 23:18:25', 'ADMIN', 'Organizational Competency', '11111111111111', 'VGhpcyBpcyBhIGRlc2NyaXB0aW9uIHRlc3Q=', 'eyJCYXNpYyI6WyIxMTExMTExMTExMTEiLCIyMjIyMjIyMjIyIiwiampoampqamoiXSwiSW50ZXJtZWRpYXRlIjpbInFxcXFxcXFxcXFxcSIsImFhYWFhYWFhYWFhYWFhYWFhYWEiLCJkZmRmZCIsInNzc3MiLCJzc2RnaGoiXSwiQWR2YW5jZWQiOlsiNjY2NjY2NjY2NiIsIjY2NjY2NjY2NjQ0NCIsIjQ1NjU0MzQ1NDMiXSwiU3VwZXJpb3IiOlsiZGZnaGpoZmRzZGZnaGdmZCIsImRmZ2hnZmRzZGZnaGdmZGRmZyJdfQ==');


#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(200) NOT NULL,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdby` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbldepartments` (`id`, `department`, `datecreated`, `createdby`) VALUES ('1', 'Human Resource', '2018-01-10 20:33:57', 'ADMIN');
INSERT INTO `tbldepartments` (`id`, `department`, `datecreated`, `createdby`) VALUES ('2', 'Accounting', '2018-01-10 20:33:57', 'ADMIN');
INSERT INTO `tbldepartments` (`id`, `department`, `datecreated`, `createdby`) VALUES ('3', 'Maintenance', '2018-01-10 20:34:13', 'ADMIN');


#
# TABLE STRUCTURE FOR: tblmodules
#

DROP TABLE IF EXISTS `tblmodules`;

CREATE TABLE `tblmodules` (
  `moduleid` varchar(10) NOT NULL,
  `modulename` varchar(100) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isallowed` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1000', 'Create/Post Position', '1', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1001', 'View Available Positions', '2', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1002', 'Modify Position Details', '3', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1003', 'Create Request for Recruitment', '4', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1004', 'View Request for Personnel', '5', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1005', 'Modify Request for Personnel Details', '6', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1006', 'Create Competency Index', '7', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1007', 'View Competency Index', '8', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1008', 'Modify Competency Index Details', '9', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1009', 'Create and Modify Competency Table', '10', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('2000', 'Create New User Account', '11', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('2001', 'Manage User Accounts', '12', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('2002', 'Assign Roles', '13', '1');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('3000', 'Create Database Backup', '14', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('3001', 'View Audit Trail', '15', '0');


#
# TABLE STRUCTURE FOR: tblpersonnelrequest
#

DROP TABLE IF EXISTS `tblpersonnelrequest`;

CREATE TABLE `tblpersonnelrequest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requestnumber` varchar(100) NOT NULL,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdby` varchar(100) NOT NULL,
  `requestorname` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `positioncode` varchar(100) NOT NULL,
  `positionname` varchar(300) NOT NULL,
  `reason` varchar(1000) NOT NULL,
  `levelofapproval` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `positionqualification` varchar(3000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblposition
#

DROP TABLE IF EXISTS `tblposition`;

CREATE TABLE `tblposition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `positioncode` varchar(50) NOT NULL,
  `positionname` varchar(1000) NOT NULL,
  `positiontype` varchar(100) NOT NULL,
  `positiondesc` varchar(500) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `tblposition` (`id`, `datecreated`, `datemodified`, `positioncode`, `positionname`, `positiontype`, `positiondesc`, `createdby`, `status`) VALUES ('8', '2018-01-21 22:03:46', '2018-01-21 22:03:46', 'INFODESKSTAF1', 'Information Desk Staff 1', 'CASUAL', 'VGhpcyBpcyBhIGRlc2NyaXB0aW9uIHRlc3Q=', 'HRD1234567890', '0');
INSERT INTO `tblposition` (`id`, `datecreated`, `datemodified`, `positioncode`, `positionname`, `positiontype`, `positiondesc`, `createdby`, `status`) VALUES ('9', '2018-01-26 11:56:51', '2018-01-26 11:56:51', 'ADMIAIDEIII', 'Administrative Aide III', 'CASUAL', 'UHJvdmlkZSBjbGVyaWNhbCBzdXBwb3J0IHRvIHRoZSBvZmZpY2Uu', 'ADMIN', '0');


#
# TABLE STRUCTURE FOR: tblqualification
#

DROP TABLE IF EXISTS `tblqualification`;

CREATE TABLE `tblqualification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbluserconfiguration
#

DROP TABLE IF EXISTS `tbluserconfiguration`;

CREATE TABLE `tbluserconfiguration` (
  `username` varchar(50) NOT NULL,
  `moduleid` varchar(10) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=128 DEFAULT CHARSET=latin1;

INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '2002', '77');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '2000', '78');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '2001', '79');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1007', '113');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1001', '112');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '3001', '111');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1002', '110');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1008', '109');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '2001', '108');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1000', '107');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1003', '106');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '2000', '105');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1006', '104');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1009', '103');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1000', '91');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1001', '92');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1002', '93');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1003', '94');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1004', '95');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1005', '96');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1006', '97');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1007', '98');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1008', '99');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1009', '100');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '3000', '101');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '3001', '102');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1004', '114');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1009', '115');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1006', '116');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1003', '117');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1000', '118');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1008', '119');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1002', '120');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1005', '121');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1001', '122');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1007', '123');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ID234567', '1004', '124');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('MAYOR01', '2001', '127');


#
# TABLE STRUCTURE FOR: tbluserdetails
#

DROP TABLE IF EXISTS `tbluserdetails`;

CREATE TABLE `tbluserdetails` (
  `username` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `contactnumber` varchar(50) NOT NULL,
  `address` varchar(300) NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `filepath` varchar(45) DEFAULT NULL,
  `department` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('ADMIN', 'admin.png', '09191234567', 'Carmona Cavite', '1990-11-16', NULL, 'uploads/profile_pictures/', 'Human Resource');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('HRD1234567890', '1516543247.png', '639199099999', 'CARMONA CAVITE', '1990-01-01', 'FEMALE', 'uploads/profile_pictures/', '');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('ID234567', 'NOIMAGE.jpg', '639123456543', 'PAGBILAO', '2018-11-03', 'MALE', 'uploads/profile_pictures/', 'Human Resource');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('MAYOR001', '1519324986.png', '639912345654', 'CARMONA CAVITE', '2018-03-02', 'FEMALE', 'uploads/profile_pictures/', '');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('ITMGR001', 'NOIMAGE.jpg', '639234565432', 'CAVITE', '2018-03-02', 'MALE', 'uploads/profile_pictures/', '');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('DEPTHEAD001', 'NOIMAGE.jpg', '639012345654', 'CAVITE', '2018-02-22', 'FEMALE', 'uploads/profile_pictures/', 'Human Resource');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('MAYOR01', 'NOIMAGE.jpg', '639234567654', 'CARMONA CAVITE', '2018-02-15', 'FEMALE', 'uploads/profile_pictures/', '');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('EliMap2018-001', 'NOIMAGE.jpg', '639234567876', 'CAVITE', '2018-02-22', 'FEMALE', 'uploads/profile_pictures/', '');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('SERVANT001', 'NOIMAGE.jpg', '639765434567', 'CAVITE', '2018-02-16', 'FEMALE', 'uploads/profile_pictures/', '');


#
# TABLE STRUCTURE FOR: tblusers
#

DROP TABLE IF EXISTS `tblusers`;

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `userlevel` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('1', '2017-12-16 21:12:29', '2018-01-21 22:24:24', 'ADMIN', 'afecd53d8d4a65b84622cab7f76d3b06', 'JUAN', 'SANTOS', 'DELA CRUZ', 'ADMINISTRATOR', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('18', '2018-01-21 22:00:47', '2018-01-21 22:00:47', 'HRD1234567890', '3677c101cca970d5595e8579d92a93ea', 'JUANA', 'SANTOS', 'DELA CRUZ', 'HRMANAGER', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('19', '2018-02-11 23:16:21', '2018-02-11 23:16:21', 'ID234567', '66f0ace171acacd0a68089c56f7f2c02', 'JOHN', 'CARLO', 'RABE', 'DEPARTMENTHEAD', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('20', '2018-02-23 01:47:47', '2018-02-23 02:44:55', 'MAYOR001', '3c5ce11503600a6d9fa978ba831d42e3', 'CLEOFE', 'GARCIA', 'GARCIA', 'MUNICIPALHEAD', '1');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('21', '2018-02-23 01:49:12', '2018-02-23 03:17:48', 'ITMGR001', '7b74acba45eaf1e9eb2786de2e6fb5f2', 'ANTONIO', 'A', 'LUNA', 'ITADMIN', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('22', '2018-02-23 02:22:15', '2018-02-23 02:22:15', 'DEPTHEAD001', '9f2f4c65cc48c15d0d703aa1c7b94235', 'GABRIELA', 'MARIE', 'SILANG', 'DEPARTMENTHEAD', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('23', '2018-02-23 02:45:25', '2018-02-23 02:45:25', 'MAYOR01', 'a14676c3462a501ead0ae83d5d360ef5', 'CLEOFE', 'G', 'GARCIA', 'MUNICIPALHEAD', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('24', '2018-02-23 04:36:20', '2018-02-23 04:36:50', 'EliMap2018-001', '897a901e800aec96358672ed072b44ec', 'ELIZA', 'A', 'MAPANOO', 'HRDSTAFF', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('25', '2018-02-23 04:38:36', '2018-02-23 04:38:36', 'SERVANT001', '46d9dad286a5f44d4d63f32eb931164c', 'KRISTINA', 'A', 'PEREZ', 'HRDSTAFF', '0');


