#
# TABLE STRUCTURE FOR: tblaudittrail
#

DROP TABLE IF EXISTS `tblaudittrail`;

CREATE TABLE `tblaudittrail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(100) NOT NULL,
  `action` varchar(300) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user` varchar(100) NOT NULL,
  `ipaddress` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=189 DEFAULT CHARSET=latin1;

INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('166', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 13:31:34', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('167', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 13:43:25', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('168', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 13:43:29', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('169', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 13:59:11', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('170', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 13:59:14', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('171', 'Account Module', 'Create User Account [HRD1234567890]', '2018-01-21 14:00:47', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('172', 'Account Module', 'Assign Roles [HRD1234567890]', '2018-01-21 14:01:44', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('173', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 14:01:50', 'ADMIN', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('174', 'Session Module', 'User Log In [HRD1234567890]', '2018-01-21 14:02:01', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('175', 'RSP Module', 'Create New Competency Title', '2018-01-21 14:02:59', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('176', 'RSP Module', 'Create New Position [INFODESKSTAF1]', '2018-01-21 14:03:46', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('177', 'Session Module', 'User Log Out [HRD1234567890]', '2018-01-21 14:06:33', 'HRD1234567890', '127.0.0.1');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('178', 'Session Module', 'User Log In [HRD1234567890]', '2018-01-21 14:06:37', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('179', 'Session Module', 'User Log Out [HRD1234567890]', '2018-01-21 14:11:14', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('180', 'Session Module', 'User Log In [HRD1234567890]', '2018-01-21 14:12:45', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('181', 'Session Module', 'User Log Out [HRD1234567890]', '2018-01-21 14:12:50', 'HRD1234567890', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('182', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 14:12:56', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('183', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 14:16:31', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('184', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 14:16:35', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('185', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 14:18:31', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('186', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 14:22:00', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('187', 'Session Module', 'User Log Out [ADMIN]', '2018-01-21 14:22:03', 'ADMIN', '223.25.26.243');
INSERT INTO `tblaudittrail` (`id`, `modulename`, `action`, `timestamp`, `user`, `ipaddress`) VALUES ('188', 'Session Module', 'User Log In [ADMIN]', '2018-01-21 14:23:15', 'ADMIN', '223.25.26.243');


#
# TABLE STRUCTURE FOR: tblbackups
#

DROP TABLE IF EXISTS `tblbackups`;

CREATE TABLE `tblbackups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdby` varchar(100) NOT NULL,
  `backupname` varchar(100) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `path` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblcompetency
#

DROP TABLE IF EXISTS `tblcompetency`;

CREATE TABLE `tblcompetency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `title` varchar(100) NOT NULL,
  `description` varchar(3000) NOT NULL,
  `createdby` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `tblcompetency` (`id`, `datecreated`, `title`, `description`, `createdby`) VALUES ('13', '2018-01-21 14:02:59', 'Organizational Competency', 'VGhpcyBpcyBhIGRlc2NyaXB0aW9uIHRlc3Q=', 'HRD1234567890');


#
# TABLE STRUCTURE FOR: tblcompetencyindex
#

DROP TABLE IF EXISTS `tblcompetencyindex`;

CREATE TABLE `tblcompetencyindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdby` varchar(50) NOT NULL,
  `competencytitle` varchar(100) NOT NULL,
  `competencyarea` varchar(100) NOT NULL,
  `competencydescription` varchar(1000) NOT NULL,
  `levels` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tblcompetencyindex` (`id`, `datecreated`, `datemodified`, `createdby`, `competencytitle`, `competencyarea`, `competencydescription`, `levels`) VALUES ('2', '2018-01-02 14:55:12', '2018-01-13 16:41:23', 'ADMIN', 'Organizational Competencies', 'EXEMPLIFYING INTEGRITY', 'VGhlIGFiaWxpdHkgdG8gZXhlbXBsaWZ5IGhpZ2ggc3RhbmRhcmRzIG9mIHByb2Zlc3Npb25hbCBiZWhhdmlvciBhcyBwdWJsaWMgc2VydmFudHMuIGFkaGVyaW5nIHRvIGV0aGljYWwgYXMgd2VsbCBhcyBtb3JhbCBwcmluY2lwbGVzLCB2YWx1ZXMgYW5kIHN0YW5kYXJkcyBvZiBwdWJsaWMgb2ZmaWNl', 'eyJjb3JlRGVzY3JpcHRpb24iOnsiYmFzaWMiOiJBY2tub3dsZWRnZXMgYW5kIHJlc3BlY3RzIGF1dGhvcml0eSwgYW5kIGRlbW9uc3RyYXRlcyByZWFkaW5lc3MgaW4gYWNjZXB0aW5nIGFuZCBjb21wbHlpbmcgd2l0aCBydWxlcy4iLCJpbnRlcm1lZGlhdGUiOiJEZW1vbnN0cmF0ZXMgY29tcGxpYW5jZSB0byBwb2xpY2llcywgcnVsZXMgYW5vdGhlciBzdGFuZGFyZHMgc2V0IGJ5IHRoZSBDb21taXNzaW9uIiwiYWR2YW5jZWQiOiJJbmZsdWVuY2VzIG90aGVycyB0byBvYnNlcnZlIGFuZC9vciBhZGhlcmUgdG8gdGhlIHBvbGljaWVzLCBydWxlcyBhbmQgb3RoZXIgc3RhbmRhcmRzIHNldCBieSB0aGUgQ29tbWlzc2lvbiIsInN1cGVyaW9yIjoiQWN0aXZlbHkgYWR2b2NhdGVzIHRoZSBwb2xpY2llcywgcnVsZXMgYW5kIG90aGVyIHN0YW5kYXJkcyBzZXQgYnkgdGhlIENvbW1pc3Npb24ifSwiYmVoYXZpb3JhbEluZGljYXRvcnMiOnsiYmFzaWMiOiJBY2tub3dsZWRnZXMgYW5kIHJlc3BlY3RzIGF1dGhvcml0eSwgYW5kIGRlbW9uc3RyYXRlcyByZWFkaW5lc3MgaW4gYWNjZXB0aW5nIGFuZCBjb21wbHlpbmcgd2l0aCBydWxlcy4iLCJpbnRlcm1lZGlhdGUiOiJEZW1vbnN0cmF0ZXMgY29tcGxpYW5jZSB0byBwb2xpY2llcywgcnVsZXMgYW5vdGhlciBzdGFuZGFyZHMgc2V0IGJ5IHRoZSBDb21taXNzaW9uIiwiYWR2YW5jZWQiOiJJbmZsdWVuY2VzIG90aGVycyB0byBvYnNlcnZlIGFuZC9vciBhZGhlcmUgdG8gdGhlIHBvbGljaWVzLCBydWxlcyBhbmQgb3RoZXIgc3RhbmRhcmRzIHNldCBieSB0aGUgQ29tbWlzc2lvbiIsInN1cGVyaW9yIjoiQWN0aXZlbHkgYWR2b2NhdGVzIHRoZSBwb2xpY2llcywgcnVsZXMgYW5kIG90aGVyIHN0YW5kYXJkcyBzZXQgYnkgdGhlIENvbW1pc3Npb24ifX0=');


#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(200) NOT NULL,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdby` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbldepartments` (`id`, `department`, `datecreated`, `createdby`) VALUES ('1', 'Human Resource', '2018-01-10 12:33:57', 'ADMIN');
INSERT INTO `tbldepartments` (`id`, `department`, `datecreated`, `createdby`) VALUES ('2', 'Accounting', '2018-01-10 12:33:57', 'ADMIN');
INSERT INTO `tbldepartments` (`id`, `department`, `datecreated`, `createdby`) VALUES ('3', 'Maintenance', '2018-01-10 12:34:13', 'ADMIN');


#
# TABLE STRUCTURE FOR: tblmodules
#

DROP TABLE IF EXISTS `tblmodules`;

CREATE TABLE `tblmodules` (
  `moduleid` varchar(10) NOT NULL,
  `modulename` varchar(100) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isallowed` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1000', 'Create/Post Position', '1', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1001', 'View Available Positions', '2', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1002', 'Modify Position Details', '3', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1003', 'Create Request for Recruitment', '4', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1004', 'View Request for Personnel', '5', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1005', 'Modify Request for Personnel Details', '6', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1006', 'Create Competency Index', '7', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1007', 'View Competency Index', '8', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1008', 'Modify Competency Index Details', '9', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('1009', 'Create and Modify Competency Table', '10', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('2000', 'Create New User Account', '11', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('2001', 'Manage User Accounts', '12', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('2002', 'Assign Roles', '13', '1');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('3000', 'Create Database Backup', '14', '0');
INSERT INTO `tblmodules` (`moduleid`, `modulename`, `id`, `isallowed`) VALUES ('3001', 'View Audit Trail', '15', '0');


#
# TABLE STRUCTURE FOR: tblpersonnelrequest
#

DROP TABLE IF EXISTS `tblpersonnelrequest`;

CREATE TABLE `tblpersonnelrequest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requestnumber` varchar(100) NOT NULL,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdby` varchar(100) NOT NULL,
  `requestorname` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  `positioncode` varchar(100) NOT NULL,
  `positionname` varchar(300) NOT NULL,
  `reason` varchar(1000) NOT NULL,
  `levelofapproval` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `positionqualification` varchar(3000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblposition
#

DROP TABLE IF EXISTS `tblposition`;

CREATE TABLE `tblposition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `positioncode` varchar(50) NOT NULL,
  `positionname` varchar(1000) NOT NULL,
  `positiontype` varchar(100) NOT NULL,
  `positiondesc` varchar(500) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tblposition` (`id`, `datecreated`, `datemodified`, `positioncode`, `positionname`, `positiontype`, `positiondesc`, `createdby`, `status`) VALUES ('8', '2018-01-21 14:03:46', '2018-01-21 14:03:46', 'INFODESKSTAF1', 'Information Desk Staff 1', 'CASUAL', 'VGhpcyBpcyBhIGRlc2NyaXB0aW9uIHRlc3Q=', 'HRD1234567890', '0');


#
# TABLE STRUCTURE FOR: tblqualification
#

DROP TABLE IF EXISTS `tblqualification`;

CREATE TABLE `tblqualification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbluserconfiguration
#

DROP TABLE IF EXISTS `tbluserconfiguration`;

CREATE TABLE `tbluserconfiguration` (
  `username` varchar(50) NOT NULL,
  `moduleid` varchar(10) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;

INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '2002', '77');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '2000', '78');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '2001', '79');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1009', '80');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1006', '81');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '2000', '82');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1000', '83');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '2001', '84');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1008', '85');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1002', '86');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '3001', '87');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1001', '88');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1007', '89');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('HRD1234567890', '1004', '90');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1000', '91');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1001', '92');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1002', '93');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1003', '94');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1004', '95');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1005', '96');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1006', '97');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1007', '98');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1008', '99');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '1009', '100');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '3000', '101');
INSERT INTO `tbluserconfiguration` (`username`, `moduleid`, `id`) VALUES ('ADMIN', '3001', '102');


#
# TABLE STRUCTURE FOR: tbluserdetails
#

DROP TABLE IF EXISTS `tbluserdetails`;

CREATE TABLE `tbluserdetails` (
  `username` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `contactnumber` varchar(50) NOT NULL,
  `address` varchar(300) NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `filepath` varchar(45) DEFAULT NULL,
  `department` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('ADMIN', 'admin.png', '09191234567', 'Carmona Cavite', '1990-11-16', NULL, 'uploads/profile_pictures/', 'Human Resource');
INSERT INTO `tbluserdetails` (`username`, `filename`, `contactnumber`, `address`, `birthday`, `gender`, `filepath`, `department`) VALUES ('HRD1234567890', '1516543247.png', '639199099999', 'CARMONA CAVITE', '1990-01-01', 'FEMALE', 'uploads/profile_pictures/', '');


#
# TABLE STRUCTURE FOR: tblusers
#

DROP TABLE IF EXISTS `tblusers`;

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `userlevel` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('1', '2017-12-16 13:12:29', '2017-12-16 13:12:29', 'ADMIN', 'afecd53d8d4a65b84622cab7f76d3b06', 'JUAN', 'SANTOS', 'DELA CRUZ', 'ADMINISTRATOR', '0');
INSERT INTO `tblusers` (`id`, `datecreated`, `datemodified`, `username`, `password`, `firstname`, `middlename`, `lastname`, `userlevel`, `status`) VALUES ('18', '2018-01-21 14:00:47', '2018-01-21 14:00:47', 'HRD1234567890', '3677c101cca970d5595e8579d92a93ea', 'JUANA', 'SANTOS', 'DELA CRUZ', 'HRMANAGER', '0');


